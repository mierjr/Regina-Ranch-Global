// Traducciones
const translations = {
  es: { /* Traducciones en español */ },
  en: { /* Traducciones en inglés */ },
  // Más idiomas...
};

function changeLanguage(lang) {
  const elements = document.querySelectorAll("[data-lang]");
  elements.forEach((el) => {
    const key = el.getAttribute("data-lang");
    if (translations[lang]?.[key]) {
      el.textContent = translations[lang][key];
    }
  });
}