// JavaScript interactivity can be added here
console.log("Welcome to Regina Ranch Global!");