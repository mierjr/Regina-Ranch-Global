function toggleDropdown() {
  const dropdown = document.getElementById("language-options");
  if (dropdown.style.display === "block") {
    dropdown.style.display = "none";
  } else {
    dropdown.style.display = "block";
  }
}

function changeLanguage(lang) {
  // Aquí puedes integrar tu lógica para cambiar el idioma de la página.
  console.log(`Idioma cambiado a: ${lang}`);
  // Por ejemplo, puedes llamar a la función changeLanguage existente para traducir el contenido.
  changeLanguage(lang);
}